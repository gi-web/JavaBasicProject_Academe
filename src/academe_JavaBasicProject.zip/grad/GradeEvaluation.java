package grad;

public interface GradeEvaluation {
	public String getGrade(int point);

}
